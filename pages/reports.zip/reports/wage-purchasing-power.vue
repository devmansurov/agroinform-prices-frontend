<template>
  <v-row>
    <v-col cols="12">
      <!-- Filters -->
      <v-expansion-panels v-model="filterPanel" class="mb-4">
        <v-expansion-panel>
          <v-expansion-panel-header color="teal lighten-1" class="white--text">
            {{ $t('filter') }}
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-row align="center" class="mt-2">
              <v-col cols="12" md="3">
                <v-text-field
                  :label="$t('year')"
                  v-model.number="selectedYear"
                  outlined
                  dense
                  hide-details
                  type="number"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="3">
                <v-text-field
                  :label="$t('week')"
                  v-model.number="weekNumber"
                  outlined
                  dense
                  hide-details
                  type="number"
                  min="1"
                  max="53"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="6" class="d-flex">
                <v-btn @click="fetchData" color="teal lighten-1" class="white--text">
                  {{ $t('Ok') }}
                </v-btn>
                <v-btn @click="resetFilter" color="teal lighten-1" class="white--text ml-2">
                  {{ $t('reset_filter') }}
                </v-btn>
              </v-col>
            </v-row>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>

      <!-- Loading Bar -->
      <v-progress-linear
        v-if="loading"
        indeterminate
        color="yellow darken-2"
        class="mb-4"
      ></v-progress-linear>

      <!-- Page Header -->
      <v-card class="mb-4" v-if="reportData">
        <v-card-title class="teal--text">
          {{ $t('wage_purchasing_power_report') }}
        </v-card-title>
        <v-card-subtitle>
          {{ countryName() }} - {{ $t('week') }} {{ weekNumber }}, {{ selectedYear }}
        </v-card-subtitle>
      </v-card>

      <!-- Wage and Purchasing Power Table -->
      <v-card class="mb-4" v-if="reportData && reportData.periods">
        <v-card-title class="subtitle-1 font-weight-bold">
          {{ $t('casual_labour_wage') }} {{ $t('and') }} {{ $t('purchasing_power') }}
        </v-card-title>

        <v-simple-table class="elevation-1">
          <template v-slot:default>
            <thead>
              <tr>
                <th class="text-center">{{ $t('number_short') }}</th>
                <th class="text-center">{{ $t('date') }}</th>
                <th class="text-center">{{ $t('reporting_period') }}</th>
                <th class="text-center">
                  <div class="header-with-icon">
                    <img src="/icons/wage-icon.jpg" alt="Wage" class="header-icon-small" />
                    <div>{{ $t('daily_wage') }}</div>
                    <div class="caption">({{ $t('tjs') }})</div>
                  </div>
                </th>
                <th class="text-center">{{ $t('working_days') }}</th>
                <th class="text-center">
                  <div class="header-with-icon">
                    <img src="/icons/wage-icon.jpg" alt="Wage" class="header-icon-small" />
                    <div>{{ $t('monthly_wage') }}</div>
                    <div class="caption">({{ $t('tjs') }})</div>
                  </div>
                </th>
                <th class="text-center">
                  <div class="header-with-icon">
                    <img src="/icons/food-basket-icon.jpg" alt="Food Basket" class="header-icon-small" />
                    <div>{{ $t('food_basket_cost') }}</div>
                    <div class="caption">({{ $t('tjs') }})</div>
                  </div>
                </th>
                <th class="text-center">
                  <div class="header-with-icon">
                    <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="header-icon-small" />
                    <div>{{ $t('purchasing_power') }}</div>
                    <div class="caption">({{ $t('baskets') }})</div>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(row, index) in tableData" :key="index">
                <td class="text-center">{{ index + 1 }}</td>
                <td class="text-center">{{ formatDate(row.date_start) }}</td>
                <td class="font-weight-bold">{{ row.period_name }}</td>
                <td class="text-center">{{ formatNumber(row.daily_wage, 2) }}</td>
                <td class="text-center">{{ formatNumber(row.working_days, 2) }}</td>
                <td class="text-center font-weight-bold">{{ formatNumber(row.monthly_wage, 0) }}</td>
                <td class="text-center font-weight-bold">{{ formatNumber(row.food_basket_total, 0) }}</td>
                <td class="text-center font-weight-bold">{{ formatNumber(row.purchasing_power, 2) }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card>

      <!-- Summary Cards -->
      <v-row v-if="reportData && reportData.periods">
        <v-col cols="12" md="4">
          <v-card class="text-center" color="teal lighten-5">
            <v-card-title class="justify-center">
              <img src="/icons/wage-icon.jpg" alt="Wage" class="summary-icon" />
            </v-card-title>
            <v-card-subtitle>{{ $t('current_week') }}</v-card-subtitle>
            <v-card-text>
              <div class="text-h4 teal--text">{{ formatNumber(reportData.periods.currentWeek.monthly_wage, 0) }} {{ $t('tjs') }}</div>
              <div class="caption">{{ $t('monthly_wage') }}</div>
              <div class="mt-2 caption">
                {{ $t('daily_wage') }}: {{ formatNumber(reportData.periods.currentWeek.daily_wage, 2) }} {{ $t('tjs') }}
              </div>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" md="4">
          <v-card class="text-center" color="blue lighten-5">
            <v-card-title class="justify-center">
              <img src="/icons/food-basket-icon.jpg" alt="Food Basket" class="summary-icon" />
            </v-card-title>
            <v-card-subtitle>{{ $t('current_week') }}</v-card-subtitle>
            <v-card-text>
              <div class="text-h4 blue--text">{{ formatNumber(reportData.periods.currentWeek.food_basket_total, 0) }} {{ $t('tjs') }}</div>
              <div class="caption">{{ $t('food_basket_cost') }}</div>
              <div class="mt-2 caption">
                {{ $t('for') }} 6 {{ $t('people') }}
              </div>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" md="4">
          <v-card class="text-center" color="orange lighten-5">
            <v-card-title class="justify-center">
              <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="summary-icon" />
            </v-card-title>
            <v-card-subtitle>{{ $t('current_week') }}</v-card-subtitle>
            <v-card-text>
              <div class="text-h4 orange--text">{{ formatNumber(reportData.periods.currentWeek.purchasing_power, 2) }}</div>
              <div class="caption">{{ $t('baskets') }}</div>
              <div class="mt-2 caption">
                {{ $t('purchasing_power') }}
              </div>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>

      <!-- Error Snackbar -->
      <v-snackbar v-model="axiosError" top centered color="red">
        {{ axiosErrorMsg }}
        <template v-slot:action="{ attrs }">
          <v-btn color="white" text v-bind="attrs" @click="axiosError = false">
            {{ $t('close') }}
          </v-btn>
        </template>
      </v-snackbar>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: 'WagePurchasingPowerReport',

  head() {
    return {
      title: this.$i18n.t('wage_purchasing_power_report')
    };
  },

  data() {
    return {
      loading: false,
      filterPanel: 0,
      selectedYear: 2024,
      weekNumber: 13,
      axiosError: false,
      axiosErrorMsg: '',
      reportData: null
    };
  },

  computed: {
    tableData() {
      if (!this.reportData || !this.reportData.periods) return [];

      const periods = this.reportData.periods;

      return [
        {
          period_name: this.$t('current_week'),
          date_start: periods.currentWeek.date_start,
          daily_wage: periods.currentWeek.daily_wage,
          working_days: periods.currentWeek.working_days,
          monthly_wage: periods.currentWeek.monthly_wage,
          food_basket_total: periods.currentWeek.food_basket_total,
          purchasing_power: periods.currentWeek.purchasing_power
        },
        {
          period_name: this.$t('last_week'),
          date_start: periods.lastWeek.date_start,
          daily_wage: periods.lastWeek.daily_wage,
          working_days: periods.lastWeek.working_days,
          monthly_wage: periods.lastWeek.monthly_wage,
          food_basket_total: periods.lastWeek.food_basket_total,
          purchasing_power: periods.lastWeek.purchasing_power
        },
        {
          period_name: this.$t('last_month'),
          date_start: periods.lastMonth.date_start,
          daily_wage: periods.lastMonth.daily_wage,
          working_days: periods.lastMonth.working_days,
          monthly_wage: periods.lastMonth.monthly_wage,
          food_basket_total: periods.lastMonth.food_basket_total,
          purchasing_power: periods.lastMonth.purchasing_power
        },
        {
          period_name: this.$t('three_months_ago'),
          date_start: periods.threeMonthsAgo.date_start,
          daily_wage: periods.threeMonthsAgo.daily_wage,
          working_days: periods.threeMonthsAgo.working_days,
          monthly_wage: periods.threeMonthsAgo.monthly_wage,
          food_basket_total: periods.threeMonthsAgo.food_basket_total,
          purchasing_power: periods.threeMonthsAgo.purchasing_power
        },
        {
          period_name: this.$t('last_year'),
          date_start: periods.lastYear.date_start,
          daily_wage: periods.lastYear.daily_wage,
          working_days: periods.lastYear.working_days,
          monthly_wage: periods.lastYear.monthly_wage,
          food_basket_total: periods.lastYear.food_basket_total,
          purchasing_power: periods.lastYear.purchasing_power
        },
        {
          period_name: this.$t('three_years_ago'),
          date_start: periods.threeYearsAgo.date_start,
          daily_wage: periods.threeYearsAgo.daily_wage,
          working_days: periods.threeYearsAgo.working_days,
          monthly_wage: periods.threeYearsAgo.monthly_wage,
          food_basket_total: periods.threeYearsAgo.food_basket_total,
          purchasing_power: periods.threeYearsAgo.purchasing_power
        }
      ];
    }
  },

  mounted() {
    let countryId = this.$cookies.get('country_id');
    if (countryId) {
      this.$store.commit('setCountryID', countryId);
      this.fetchData();
    }
  },

  methods: {
    countryName() {
      if (this.$store.state.countryId == 1) return this.$t('tajikistan');
      else if (this.$store.state.countryId == 2) return this.$t('kyrgyzstan');
      else return '';
    },

    async fetchData() {
      this.loading = true;
      try {
        let response = await this.$axios.get(
          `/v1/food-basket-breakdown/${this.$store.state.countryId}/${this.$i18n.locale}`,
          {
            params: {
              year: this.selectedYear,
              week: this.weekNumber
            }
          }
        );

        if (response.status == 200) {
          this.reportData = response.data;
        }
      } catch (err) {
        this.axiosError = true;
        this.axiosErrorMsg = this.$t('no_data_available');
        console.error(err);
      } finally {
        this.loading = false;
      }
    },

    resetFilter() {
      this.selectedYear = 2024;
      this.weekNumber = 13;
      this.fetchData();
    },

    formatNumber(value, decimals = 0) {
      if (value === null || value === undefined) return '-';
      return Number(value).toFixed(decimals);
    },

    formatDate(dateString) {
      if (!dateString) return '-';
      const date = new Date(dateString);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}.${month}.${year}`;
    }
  }
};
</script>

<style scoped>
.v-simple-table td,
.v-simple-table th {
  padding: 12px 8px !important;
  font-size: 13px;
}

.v-simple-table th {
  font-weight: bold !important;
  background-color: #f5f5f5;
}

.header-with-icon {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.header-icon-small {
  width: 50px;
  height: 50px;
  object-fit: contain;
}

.summary-icon {
  width: 80px;
  height: 80px;
  object-fit: contain;
}

/* Print Styles */
@media print {
  @page {
    size: A4;
    margin: 15mm;
  }

  .v-expansion-panels,
  .v-progress-linear,
  .v-snackbar {
    display: none !important;
  }

  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  .elevation-1,
  .v-card {
    box-shadow: none !important;
    page-break-inside: avoid;
  }

  .v-simple-table {
    border: 1px solid #ddd !important;
  }

  .v-simple-table th {
    background-color: #f5f5f5 !important;
    border: 1px solid #ddd !important;
  }

  .v-simple-table td {
    border: 1px solid #ddd !important;
  }

  .v-row {
    page-break-inside: avoid;
  }
}
</style>
