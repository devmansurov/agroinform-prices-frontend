<template>
  <v-row>
    <v-col cols="12">
      <!-- Filters -->
      <v-expansion-panels v-model="filterPanel" class="mb-4">
        <v-expansion-panel>
          <v-expansion-panel-header color="teal lighten-1" class="white--text">
            {{ $t('filter') }}
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-row align="center" class="mt-2">
              <v-col cols="12" md="3">
                <v-text-field
                  :label="$t('year')"
                  v-model.number="selectedYear"
                  outlined
                  dense
                  hide-details
                  type="number"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="3">
                <v-text-field
                  :label="$t('week')"
                  v-model.number="weekNumber"
                  outlined
                  dense
                  hide-details
                  type="number"
                  min="1"
                  max="53"
                ></v-text-field>
              </v-col>
              <v-col cols="12" md="6" class="d-flex">
                <v-btn @click="fetchFoodBasketData" color="teal lighten-1" class="white--text">
                  {{ $t('Ok') }}
                </v-btn>
                <v-btn @click="resetFilter" color="teal lighten-1" class="white--text ml-2">
                  {{ $t('reset_filter') }}
                </v-btn>
              </v-col>
            </v-row>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>

      <!-- Loading Bar -->
      <v-progress-linear
        v-if="loading"
        indeterminate
        color="yellow darken-2"
        class="mb-4"
      ></v-progress-linear>

      <!-- Page Header -->
      <v-card class="mb-4" v-if="foodBasketData">
        <v-card-title class="teal--text">
          {{ $t('food_basket_breakdown') }}
        </v-card-title>
        <v-card-subtitle>
          {{ countryName() }} - {{ $t('week') }} {{ weekNumber }}, {{ selectedYear }}
        </v-card-subtitle>
      </v-card>

      <!-- Food Basket Products Table -->
      <v-card class="mb-4" v-if="foodBasketData && foodBasketData.products">
        <v-card-title class="subtitle-1 font-weight-bold">
          {{ $t('food_basket_products') }}
        </v-card-title>

        <v-simple-table class="elevation-1">
          <template v-slot:default>
            <thead>
              <tr>
                <th rowspan="2" class="text-left">№</th>
                <th rowspan="2" class="text-left">{{ $t('product') }}</th>
                <th rowspan="2" class="text-center">{{ $t('unit') }}</th>
                <th colspan="2" class="text-center">{{ $t('qty_per_month') }}</th>
                <th colspan="2" class="text-center">{{ $t('current_week') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_week') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_month') }}</th>
                <th colspan="2" class="text-center">{{ $t('three_months_ago') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_year') }}</th>
                <th colspan="2" class="text-center">{{ $t('three_years_ago') }}</th>
              </tr>
              <tr>
                <!-- Qty/month sub-headers -->
                <th class="text-center">{{ $t('pp') }}</th>
                <th class="text-center">{{ $t('hh') }}</th>

                <!-- Current Week sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>

                <!-- Last Week sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>

                <!-- Last Month sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>

                <!-- 3 Months Ago sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>

                <!-- Last Year sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>

                <!-- 3 Years Ago sub-headers -->
                <th class="text-center">{{ $t('nap') }}</th>
                <th class="text-center">{{ $t('total') }}</th>
              </tr>
            </thead>
            <tbody>
              <!-- Product rows -->
              <tr v-for="(product, index) in foodBasketData.products" :key="product.product_id">
                <td>{{ index + 1 }}</td>
                <td>{{ product.product_name }}</td>
                <td class="text-center">{{ product.unit }}</td>
                <td class="text-center">{{ formatNumber(product.pp_quantity, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.hh_quantity, 2) }}</td>

                <!-- Current Week -->
                <td class="text-center">{{ formatNumber(product.periods.currentWeek.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.currentWeek.cost_per_household, 2) }}</td>

                <!-- Last Week -->
                <td class="text-center">{{ formatNumber(product.periods.lastWeek.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.lastWeek.cost_per_household, 2) }}</td>

                <!-- Last Month -->
                <td class="text-center">{{ formatNumber(product.periods.lastMonth.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.lastMonth.cost_per_household, 2) }}</td>

                <!-- 3 Months Ago -->
                <td class="text-center">{{ formatNumber(product.periods.threeMonthsAgo.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.threeMonthsAgo.cost_per_household, 2) }}</td>

                <!-- Last Year -->
                <td class="text-center">{{ formatNumber(product.periods.lastYear.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.lastYear.cost_per_household, 2) }}</td>

                <!-- 3 Years Ago -->
                <td class="text-center">{{ formatNumber(product.periods.threeYearsAgo.nap, 2) }}</td>
                <td class="text-center">{{ formatNumber(product.periods.threeYearsAgo.cost_per_household, 2) }}</td>
              </tr>

              <!-- Totals row -->
              <tr class="totals-row">
                <td colspan="3" class="text-right font-weight-bold">{{ $t('total') }}</td>
                <td></td>
                <td></td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.currentWeek.food_basket_total, 0) }}</td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.lastWeek.food_basket_total, 0) }}</td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.lastMonth.food_basket_total, 0) }}</td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.threeMonthsAgo.food_basket_total, 0) }}</td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.lastYear.food_basket_total, 0) }}</td>
                <td></td>
                <td class="text-center font-weight-bold">{{ formatNumber(foodBasketData.periods.threeYearsAgo.food_basket_total, 0) }}</td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card>

      <!-- Wage and Purchasing Power Section -->
      <v-card class="mb-4" v-if="foodBasketData && foodBasketData.periods">
        <v-card-title class="subtitle-1 font-weight-bold">
          {{ $t('wages_and_purchasing_power') }}
        </v-card-title>

        <v-simple-table class="elevation-1">
          <template v-slot:default>
            <thead>
              <tr>
                <th rowspan="2" class="text-left">{{ $t('indicator') }}</th>
                <th colspan="2" class="text-center">{{ $t('current_week') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_week') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_month') }}</th>
                <th colspan="2" class="text-center">{{ $t('three_months_ago') }}</th>
                <th colspan="2" class="text-center">{{ $t('last_year') }}</th>
                <th colspan="2" class="text-center">{{ $t('three_years_ago') }}</th>
              </tr>
              <tr>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
                <th class="text-center">{{ $t('value') }}</th>
                <th class="text-center">{{ $t('icon') }}</th>
              </tr>
            </thead>
            <tbody>
              <!-- Daily Wage row -->
              <tr>
                <td class="font-weight-bold">{{ $t('daily_wage') }} ({{ $t('tjs') }})</td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.currentWeek.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastWeek.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastMonth.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeMonthsAgo.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastYear.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeYearsAgo.daily_wage, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
              </tr>

              <!-- Working Days row -->
              <tr>
                <td class="font-weight-bold">{{ $t('working_days') }}</td>
                <td class="text-center">{{ foodBasketData.periods.currentWeek.working_days }}</td>
                <td></td>
                <td class="text-center">{{ foodBasketData.periods.lastWeek.working_days }}</td>
                <td></td>
                <td class="text-center">{{ foodBasketData.periods.lastMonth.working_days }}</td>
                <td></td>
                <td class="text-center">{{ foodBasketData.periods.threeMonthsAgo.working_days }}</td>
                <td></td>
                <td class="text-center">{{ foodBasketData.periods.lastYear.working_days }}</td>
                <td></td>
                <td class="text-center">{{ foodBasketData.periods.threeYearsAgo.working_days }}</td>
                <td></td>
              </tr>

              <!-- Monthly Wage row -->
              <tr>
                <td class="font-weight-bold">{{ $t('monthly_wage') }} ({{ $t('tjs') }})</td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.currentWeek.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastWeek.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastMonth.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeMonthsAgo.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastYear.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeYearsAgo.monthly_wage, 0) }}</td>
                <td class="text-center">
                  <img src="/icons/wage-icon.jpg" alt="Wage" class="indicator-icon" />
                </td>
              </tr>

              <!-- Purchasing Power row -->
              <tr>
                <td class="font-weight-bold">{{ $t('purchasing_power') }}</td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.currentWeek.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastWeek.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastMonth.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeMonthsAgo.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.lastYear.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
                <td class="text-center">{{ formatNumber(foodBasketData.periods.threeYearsAgo.purchasing_power, 2) }}</td>
                <td class="text-center">
                  <img src="/icons/purchasing-power-icon.jpg" alt="Purchasing Power" class="indicator-icon" />
                </td>
              </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-card>

      <!-- Error Snackbar -->
      <v-snackbar v-model="axiosError" top centered color="red">
        {{ axiosErrorMsg }}
        <template v-slot:action="{ attrs }">
          <v-btn color="white" text v-bind="attrs" @click="axiosError = false">
            {{ $t('close') }}
          </v-btn>
        </template>
      </v-snackbar>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: 'FoodBasketBreakdown',

  head() {
    return {
      title: this.$i18n.t('food_basket_breakdown')
    };
  },

  data() {
    return {
      loading: false,
      filterPanel: 0,
      selectedYear: 2024,
      weekNumber: 13,
      axiosError: false,
      axiosErrorMsg: '',
      foodBasketData: null
    };
  },

  mounted() {
    let countryId = this.$cookies.get('country_id');
    if (countryId) {
      this.$store.commit('setCountryID', countryId);
      this.fetchFoodBasketData();
    }
  },

  methods: {
    countryName() {
      if (this.$store.state.countryId == 1) return this.$t('tajikistan');
      else if (this.$store.state.countryId == 2) return this.$t('kyrgyzstan');
      else return '';
    },

    async fetchFoodBasketData() {
      this.loading = true;
      try {
        let response = await this.$axios.get(
          `/v1/food-basket-breakdown/${this.$store.state.countryId}/${this.$i18n.locale}`,
          {
            params: {
              year: this.selectedYear,
              week: this.weekNumber
            }
          }
        );

        if (response.status == 200) {
          this.foodBasketData = response.data;
        }
      } catch (err) {
        this.axiosError = true;
        this.axiosErrorMsg = this.$t('no_data_available');
        console.error(err);
      } finally {
        this.loading = false;
      }
    },

    resetFilter() {
      this.selectedYear = 2024;
      this.weekNumber = 13;
      this.fetchFoodBasketData();
    },

    formatNumber(value, decimals = 0) {
      if (value === null || value === undefined) return '-';
      return Number(value).toFixed(decimals);
    }
  }
};
</script>

<style scoped>
.v-data-table td,
.v-simple-table td {
  padding: 8px 4px !important;
  font-size: 12px;
}

.v-data-table th,
.v-simple-table th {
  font-weight: bold !important;
  padding: 8px 4px !important;
  font-size: 12px;
  background-color: #f5f5f5;
}

.totals-row {
  background-color: #e8f5e9;
  font-weight: bold;
}

.indicator-icon {
  width: 40px;
  height: 40px;
  object-fit: contain;
}

/* Print Styles */
@media print {
  @page {
    size: A4 landscape;
    margin: 10mm;
  }

  .v-expansion-panels,
  .v-progress-linear,
  .v-snackbar {
    display: none !important;
  }

  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  .elevation-1,
  .v-card {
    box-shadow: none !important;
  }

  .v-simple-table {
    border: 1px solid #ddd !important;
  }

  .v-simple-table th {
    background-color: #f5f5f5 !important;
    border: 1px solid #ddd !important;
  }

  .v-simple-table td {
    border: 1px solid #ddd !important;
  }

  .totals-row {
    background-color: #e8f5e9 !important;
  }
}
</style>
