<template>
  <v-row>
    <v-col cols="12">
      <!-- Filters -->
      <v-expansion-panels v-model="filterPanel" class="mb-4">
        <v-expansion-panel>
          <v-expansion-panel-header color="teal lighten-1" class="white--text">
            {{ $t('filter') }}
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <v-row align="center" class="mt-2">
              <v-col cols="12" md="2">
                <v-select
                  :label="$t('year')"
                  v-model="selectedYear"
                  :items="availableYears"
                  outlined
                  dense
                  hide-details
                  @change="onYearChange"
                ></v-select>
              </v-col>
              <v-col cols="12" md="3">
                <v-select
                  :label="$t('month')"
                  v-model="selectedMonth"
                  :items="availableMonthsFormatted"
                  item-text="name"
                  item-value="value"
                  outlined
                  dense
                  hide-details
                  :disabled="!selectedYear"
                  @change="onMonthChange"
                ></v-select>
              </v-col>
              <v-col cols="12" md="2">
                <v-select
                  :label="$t('week')"
                  v-model="weekNumber"
                  :items="availableWeeks"
                  outlined
                  dense
                  hide-details
                  :disabled="!selectedMonth"
                ></v-select>
              </v-col>
              <v-col cols="12" md="5" class="d-flex">
                <v-btn @click="fetchWeeklyReport" color="teal lighten-1" class="white--text" :disabled="!weekNumber">
                  {{ $t('Ok') }}
                </v-btn>
                <v-btn @click="resetFilter" color="teal lighten-1" class="white--text ml-2">
                  {{ $t('reset_filter') }}
                </v-btn>
              </v-col>
            </v-row>
            <v-row class="mt-4">
              <v-col cols="12">
                <v-combobox
                  :label="$t('select_products')"
                  v-model="selectedProductsObjects"
                  :items="availableProducts"
                  item-text="name"
                  item-value="id"
                  multiple
                  outlined
                  dense
                  hide-details
                  :rules="[v => v.length <= 15 || $t('max_15_products')]"
                  @input="limitProductSelection"
                ></v-combobox>
              </v-col>
            </v-row>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>

      <!-- Selected Products Display -->
      <v-card class="mb-4" v-if="selectedProducts.length > 0">
        <v-card-title class="teal--text">
          {{ $t('select_products') }} ({{ selectedProducts.length }})
        </v-card-title>
        <v-card-text>
          <v-row>
            <v-col cols="12" md="4" v-for="col in 3" :key="col">
              <ol :start="(col - 1) * 5 + 1">
                <li v-for="i in 5" :key="i" v-if="selectedProducts[(col - 1) * 5 + i - 1]">
                  {{ selectedProducts[(col - 1) * 5 + i - 1].name }}<span v-if="selectedProducts[(col - 1) * 5 + i - 1].unit">, {{ selectedProducts[(col - 1) * 5 + i - 1].unit }}</span>
                </li>
              </ol>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>

      <!-- Loading Bar -->
      <v-progress-linear
        v-if="loading"
        indeterminate
        color="yellow darken-2"
        class="mb-4"
      ></v-progress-linear>

      <!-- WFP Report Layout: Header Row -->
      <v-row class="mb-2">
        <!-- Left Column: Metadata -->
        <v-col cols="12" md="3">
          <div class="report-metadata">
            <div class="country-name">{{ countryName().toUpperCase() }}</div>
            <div class="issue-number">Issue No. {{ weekNumber }}</div>
            <div class="week-period">{{ getWeekPeriod() }}</div>
            <div class="week-year">Week {{ weekNumber }} | {{ selectedYear }}</div>
          </div>
        </v-col>

        <!-- Right Column: Report Title -->
        <v-col cols="12" md="9">
          <div class="report-title">
            {{ $t('weekly_market_report') }}
          </div>
        </v-col>
      </v-row>

      <!-- WFP Report Layout: Content Row -->
      <v-row>
        <!-- Left Column: WFP Banner -->
        <v-col cols="12" md="3">
          <img src="/wfp-banner.jpg" alt="WFP" class="wfp-banner" />
        </v-col>

        <!-- Right Column: Data Tables -->
        <v-col cols="12" md="9">
          <!-- National Summary Section -->
      <v-card class="mb-4">
        <v-card-title class="teal--text">
          {{ $t('national_level') }}: {{ $t('wages_and_purchasing_power') }}
        </v-card-title>
        <v-data-table
          :headers="nationalSummaryHeaders"
          :items="nationalSummaryData"
          :hide-default-footer="true"
          :disable-pagination="true"
          class="elevation-1"
        >
          <!-- Custom header slots with icons above text -->
          <template v-slot:header.foodBasket="{ header }">
            <div class="header-with-icon">
              <img :src="header.icon" :alt="header.text" class="header-icon" />
              <div>{{ header.text }}</div>
            </div>
          </template>
          <template v-slot:header.wage="{ header }">
            <div class="header-with-icon">
              <img :src="header.icon" :alt="header.text" class="header-icon" />
              <div>{{ header.text }}</div>
            </div>
          </template>
          <template v-slot:header.purchasingPower="{ header }">
            <div class="header-with-icon">
              <img :src="header.icon" :alt="header.text" class="header-icon" />
              <div>{{ header.text }}</div>
            </div>
          </template>

          <template v-slot:item.period="{ item }">
            <strong>{{ item.period }}</strong>
          </template>
          <template v-slot:item.foodBasket="{ item }">
            <div :style="{ backgroundColor: getCellColor(item.foodBasketChange) }">
              {{ formatNumber(item.foodBasket) }}
              <span v-if="item.foodBasketChange !== null">
                ({{ item.foodBasketChange > 0 ? '+' : '' }}{{ item.foodBasketChange }}%) {{ getTrendIcon(item.foodBasketChange) }}
              </span>
            </div>
          </template>
          <template v-slot:item.wage="{ item }">
            <div :style="{ backgroundColor: getCellColor(item.wageChange) }">
              {{ formatNumber(item.wage) }}
              <span v-if="item.wageChange !== null">
                ({{ item.wageChange > 0 ? '+' : '' }}{{ item.wageChange }}%) {{ getTrendIcon(item.wageChange) }}
              </span>
            </div>
          </template>
          <template v-slot:item.purchasingPower="{ item }">
            <div :style="{ backgroundColor: getCellColor(item.purchasingPowerChange) }">
              {{ formatNumber(item.purchasingPower, 2) }}
              <span v-if="item.purchasingPowerChange !== null">
                ({{ item.purchasingPowerChange > 0 ? '+' : '' }}{{ item.purchasingPowerChange }}%) {{ getTrendIcon(item.purchasingPowerChange) }}
              </span>
            </div>
          </template>
        </v-data-table>
      </v-card>

      <!-- Market Comparison Section -->
      <v-card class="mb-4">
        <v-card-title class="teal--text">
          {{ $t('weekly_price_changes') }}
        </v-card-title>

        <v-card-subtitle>
          {{ $t('market_comparison') }}
        </v-card-subtitle>

        <!-- Empty state if no products have data -->
        <v-alert v-if="selectedProducts.length > 0 && productsWithData.length === 0"
                 type="info"
                 outlined
                 class="ma-4">
          {{ $t('no_price_data_for_selected_period') }}
        </v-alert>

        <!-- Loop through products with data -->
        <div v-for="(product, index) in productsWithData" :key="index" class="mb-6">
          <v-card-title class="subtitle-1 font-weight-bold">
            {{ product.name }}
          </v-card-title>

          <v-data-table
            :headers="marketComparisonHeaders"
            :items="getMarketDataForProduct(product.id)"
            :hide-default-footer="true"
            :disable-pagination="true"
            class="elevation-1"
          >
            <template v-slot:item.market="{ item }">
              <strong v-if="item.isAverage">{{ $t('average') }}</strong>
              <span v-else>{{ item.marketName }}</span>
            </template>
            <template v-slot:item.currentWeek="{ item }">
              <div :style="{ backgroundColor: item.isAverage ? '#f3f3f3' : '#ffffff' }">
                {{ formatNumber(item.currentWeek, 1) }}
              </div>
            </template>
            <template v-slot:item.lastWeek="{ item }">
              <div :style="{ backgroundColor: getCellColorForMarket(item, 'lastWeek') }">
                {{ formatNumber(item.lastWeek, 1) }}
                <span v-if="item.lastWeekChange !== null">
                  ({{ item.lastWeekChange > 0 ? '+' : '' }}{{ item.lastWeekChange }}%)
                </span>
              </div>
            </template>
            <template v-slot:item.lastMonth="{ item }">
              <div :style="{ backgroundColor: getCellColorForMarket(item, 'lastMonth') }">
                {{ formatNumber(item.lastMonth, 1) }}
                <span v-if="item.lastMonthChange !== null">
                  ({{ item.lastMonthChange > 0 ? '+' : '' }}{{ item.lastMonthChange }}%)
                </span>
              </div>
            </template>
            <template v-slot:item.lastYear="{ item }">
              <div :style="{ backgroundColor: getCellColorForMarket(item, 'lastYear') }">
                {{ formatNumber(item.lastYear, 1) }}
                <span v-if="item.lastYearChange !== null">
                  ({{ item.lastYearChange > 0 ? '+' : '' }}{{ item.lastYearChange }}%)
                </span>
              </div>
            </template>
          </v-data-table>
        </div>
      </v-card>
        </v-col>
      </v-row>

      <!-- Error Snackbar -->
      <v-snackbar v-model="axiosError" top centered color="red">
        {{ axiosErrorMsg }}
        <template v-slot:action="{ attrs }">
          <v-btn color="white" text v-bind="attrs" @click="axiosError = false">
            {{ $t('close') }}
          </v-btn>
        </template>
      </v-snackbar>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: 'WeeklyReport',

  head() {
    return {
      title: this.$i18n.t('weekly_market_report')
    };
  },

  data() {
    return {
      loading: false,
      filterPanel: 0,
      selectedYear: null,
      selectedMonth: null,
      weekNumber: null,
      axiosError: false,
      axiosErrorMsg: '',

      // Filter options from API
      availableYears: [],
      availableMonths: [],
      availableWeeks: [],

      // Week date range from API
      weekStartDate: null,
      weekEndDate: null,

      // API data
      allProducts: [],
      allMarkets: [],
      marketPricesData: [],
      nationalSummaryData: [],

      // Selected products (objects for v-combobox)
      selectedProductsObjects: []
    };
  },

  computed: {
    availableProducts() {
      // Products fetched from API
      return this.allProducts;
    },

    selectedProducts() {
      // Return selected product objects
      return this.selectedProductsObjects;
    },

    selectedProductIds() {
      // Extract IDs from selected product objects
      return this.selectedProductsObjects.map(p => p.id || p);
    },

    availableMonthsFormatted() {
      // Convert month numbers to localized names
      return this.availableMonths.map(monthNum => ({
        value: monthNum,
        name: this.getMonthName(monthNum)
      }));
    },

    nationalSummaryHeaders() {
      return [
        { text: '', value: 'period', sortable: false },
        {
          text: this.$t('food_basket'),
          value: 'foodBasket',
          sortable: false,
          icon: '/icons/food-basket-icon.jpg'
        },
        {
          text: this.$t('temporary_wage'),
          value: 'wage',
          sortable: false,
          icon: '/icons/wage-icon.jpg'
        },
        {
          text: this.$t('purchasing_power'),
          value: 'purchasingPower',
          sortable: false,
          icon: '/icons/purchasing-power-icon.jpg'
        }
      ];
    },

    marketComparisonHeaders() {
      return [
        { text: this.$t('markets'), value: 'market', sortable: false },
        { text: this.$t('current_week'), value: 'currentWeek', sortable: false },
        { text: this.$t('last_week'), value: 'lastWeek', sortable: false },
        { text: this.$t('last_month'), value: 'lastMonth', sortable: false },
        { text: this.$t('last_year'), value: 'lastYear', sortable: false }
      ];
    },

    productsWithData() {
      // Filter selected products that have actual market data
      return this.selectedProducts.filter(product => {
        const marketData = this.getMarketDataForProduct(product.id);
        return marketData && marketData.length > 0;
      });
    }
  },

  mounted() {
    // Initialize with current country
    let countryId = this.$cookies.get('country_id');
    if (countryId) {
      this.$store.commit('setCountryID', countryId);
      this.fetchAvailableYears(); // Start the cascade
    }
  },

  methods: {
    countryName() {
      if (this.$store.state.countryId == 1) return this.$t('tajikistan');
      else if (this.$store.state.countryId == 2) return this.$t('kyrgyzstan');
      else return '';
    },

    getMonthName(monthNum) {
      const monthNames = [
        this.$t('Jan'), this.$t('Feb'), this.$t('March'), this.$t('April'),
        this.$t('May'), this.$t('June'), this.$t('July'), this.$t('Aug'),
        this.$t('Sep'), this.$t('Oct'), this.$t('Nov'), this.$t('Dec')
      ];
      return monthNames[monthNum - 1] || '';
    },

    getWeekPeriod() {
      // Use dates from API response if available
      if (this.weekStartDate && this.weekEndDate) {
        const start = new Date(this.weekStartDate);
        const end = new Date(this.weekEndDate);

        const monthNames = [
          this.$t('Jan'), this.$t('Feb'), this.$t('March'), this.$t('April'),
          this.$t('May'), this.$t('June'), this.$t('July'), this.$t('Aug'),
          this.$t('Sep'), this.$t('Oct'), this.$t('Nov'), this.$t('Dec')
        ];

        const startMonth = monthNames[start.getMonth()];
        const startDay = start.getDate();
        const endMonth = monthNames[end.getMonth()];
        const endDay = end.getDate();

        if (start.getMonth() === end.getMonth()) {
          return `${startMonth} ${startDay} - ${endDay}, ${start.getFullYear()}`;
        } else {
          return `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${start.getFullYear()}`;
        }
      }
      return '';
    },

    async fetchAvailableYears() {
      try {
        // TEMPORARY: Set defaults to Week 13, March 2024 for testing
        const targetYear = 2024;
        const targetMonth = 3;
        const targetWeek = 13;

        // Now fetch available years
        let yearsResponse = await this.$axios.get(
          `/v1/weekly-report-filters/${this.$store.state.countryId}`
        );

        if (yearsResponse.status == 200) {
          this.availableYears = yearsResponse.data.years || [];

          // Set year to target year for testing
          if (this.availableYears.includes(targetYear)) {
            this.selectedYear = targetYear;

            // Fetch months for this year
            await this.fetchMonthsForYear(targetYear, targetMonth, targetWeek);
          }
        }
      } catch (err) {
        console.error(err);
      }
    },

    async fetchMonthsForYear(targetYear, targetMonth, targetWeek) {
      try {
        let response = await this.$axios.get(
          `/v1/weekly-report-filters/${this.$store.state.countryId}`,
          { params: { year: targetYear } }
        );

        if (response.status == 200) {
          this.availableMonths = response.data.months || [];

          // Set month to target month if available
          if (this.availableMonths.includes(targetMonth)) {
            this.selectedMonth = targetMonth;

            // Fetch weeks for this month
            await this.fetchWeeksForMonth(targetYear, targetMonth, targetWeek);
          }
        }
      } catch (err) {
        console.error(err);
      }
    },

    async fetchWeeksForMonth(targetYear, targetMonth, targetWeek) {
      try {
        let response = await this.$axios.get(
          `/v1/weekly-report-filters/${this.$store.state.countryId}`,
          { params: { year: targetYear, month: targetMonth } }
        );

        if (response.status == 200) {
          this.availableWeeks = response.data.weeks || [];

          // Set week to target week if available
          if (this.availableWeeks.includes(targetWeek)) {
            this.weekNumber = targetWeek;

            // Automatically fetch report data for the selected period
            await this.fetchWeeklyReport();
          }
        }
      } catch (err) {
        console.error(err);
      }
    },

    async onYearChange() {
      this.selectedMonth = null;
      this.weekNumber = null;
      this.availableMonths = [];
      this.availableWeeks = [];

      if (!this.selectedYear) return;

      try {
        let response = await this.$axios.get(
          `/v1/weekly-report-filters/${this.$store.state.countryId}`,
          { params: { year: this.selectedYear } }
        );
        if (response.status == 200) {
          this.availableMonths = response.data.months || [];
          // DO NOT auto-select - let user choose manually
        }
      } catch (err) {
        console.error(err);
      }
    },

    async onMonthChange() {
      this.weekNumber = null;
      this.availableWeeks = [];

      if (!this.selectedMonth) return;

      try {
        let response = await this.$axios.get(
          `/v1/weekly-report-filters/${this.$store.state.countryId}`,
          { params: { year: this.selectedYear, month: this.selectedMonth } }
        );
        if (response.status == 200) {
          this.availableWeeks = response.data.weeks || [];
          // DO NOT auto-select - let user choose manually
        }
      } catch (err) {
        console.error(err);
      }
    },

    async fetchWeeklyReport() {
      this.loading = true;
      try {
        let productParams = '';
        if (this.selectedProductIds.length > 0) {
          productParams = this.selectedProductIds.join(',');
        }

        let response = await this.$axios.get(
          `/v1/weekly-report/${this.$store.state.countryId}/${this.$i18n.locale}`,
          {
            params: {
              year: this.selectedYear,
              week: this.weekNumber,
              products: productParams,
              exclude_empty: true
            }
          }
        );

        if (response.status == 200) {
          this.weekStartDate = response.data.week_start_date;
          this.weekEndDate = response.data.week_end_date;
          this.allProducts = response.data.products || [];
          this.allMarkets = response.data.markets || [];
          this.marketPricesData = response.data.marketPrices || [];

          // If no products selected yet, select specific 15 products matching Google Sheets
          if (this.selectedProductsObjects.length === 0 && this.allProducts.length > 0) {
            // TEMPORARY: Match Google Sheets Week 13, 2024 product selection
            const targetProductIds = [22, 64, 3, 29, 17, 63, 69, 67, 195, 13, 15, 78, 44, 32, 197];
            this.selectedProductsObjects = this.allProducts.filter(p => targetProductIds.includes(p.id));

            // Fallback to first 15 if specific products not found
            if (this.selectedProductsObjects.length === 0) {
              this.selectedProductsObjects = this.allProducts.slice(0, 15);
            }
          }

          // Generate national summary data from API response
          this.generateNationalSummary(response.data.nationalSummary);
        }
      } catch (err) {
        this.axiosError = true;
        this.axiosErrorMsg = this.$t('no_data_available');
        console.error(err);
      } finally {
        this.loading = false;
      }
    },

    generateNationalSummary(apiData) {
      // Process national summary data from API
      if (!apiData) {
        this.nationalSummaryData = [];
        return;
      }

      this.nationalSummaryData = [
        {
          period: this.$t('current_week'),
          foodBasket: apiData.current.foodBasket,
          foodBasketChange: apiData.current.foodBasketChange,
          wage: apiData.current.wage,
          wageChange: apiData.current.wageChange,
          purchasingPower: apiData.current.purchasingPower,
          purchasingPowerChange: apiData.current.purchasingPowerChange
        },
        {
          period: this.$t('last_week'),
          foodBasket: apiData.lastWeek.foodBasket,
          foodBasketChange: apiData.lastWeek.foodBasketChange,
          wage: apiData.lastWeek.wage,
          wageChange: apiData.lastWeek.wageChange,
          purchasingPower: apiData.lastWeek.purchasingPower,
          purchasingPowerChange: apiData.lastWeek.purchasingPowerChange
        },
        {
          period: this.$t('last_month'),
          foodBasket: apiData.lastMonth.foodBasket,
          foodBasketChange: apiData.lastMonth.foodBasketChange,
          wage: apiData.lastMonth.wage,
          wageChange: apiData.lastMonth.wageChange,
          purchasingPower: apiData.lastMonth.purchasingPower,
          purchasingPowerChange: apiData.lastMonth.purchasingPowerChange
        },
        {
          period: this.$t('three_months_ago'),
          foodBasket: apiData.threeMonthsAgo.foodBasket,
          foodBasketChange: apiData.threeMonthsAgo.foodBasketChange,
          wage: apiData.threeMonthsAgo.wage,
          wageChange: apiData.threeMonthsAgo.wageChange,
          purchasingPower: apiData.threeMonthsAgo.purchasingPower,
          purchasingPowerChange: apiData.threeMonthsAgo.purchasingPowerChange
        },
        {
          period: this.$t('last_year'),
          foodBasket: apiData.lastYear.foodBasket,
          foodBasketChange: apiData.lastYear.foodBasketChange,
          wage: apiData.lastYear.wage,
          wageChange: apiData.lastYear.wageChange,
          purchasingPower: apiData.lastYear.purchasingPower,
          purchasingPowerChange: apiData.lastYear.purchasingPowerChange
        },
        {
          period: this.$t('three_years_ago'),
          foodBasket: apiData.threeYearsAgo.foodBasket,
          foodBasketChange: apiData.threeYearsAgo.foodBasketChange,
          wage: apiData.threeYearsAgo.wage,
          wageChange: apiData.threeYearsAgo.wageChange,
          purchasingPower: apiData.threeYearsAgo.purchasingPower,
          purchasingPowerChange: apiData.threeYearsAgo.purchasingPowerChange
        }
      ];
    },

    getMarketDataForProduct(productId) {
      return this.marketPricesData.filter(item => item.productId === productId);
    },

    getCellColor(percentChange) {
      if (percentChange === null) return '#ffffff';

      const change = parseFloat(percentChange);
      // Color coding based on the WR.html analysis
      if (change >= 20) return '#87b189';       // Strong increase - dark green
      if (change >= 10) return '#afdeb2';       // Moderate increase - medium green
      if (change >= 5) return '#c8e7bf';        // Light increase - light green
      if (change >= 2) return '#d5ecc9';        // Very light increase - very light green
      if (change >= -2) return '#cfe2f3';       // Neutral - light blue
      if (change >= -5) return '#f7ddd6';       // Very light decrease - very light red
      if (change >= -10) return '#fec6c2';      // Light decrease - light red
      if (change >= -20) return '#ffbcb1';      // Moderate decrease - medium red
      return '#ff7d7d';                          // Strong decrease - dark red
    },

    getCellColorForMarket(item, period) {
      if (item.isAverage) return '#f3f3f3';

      let change = null;
      if (period === 'lastWeek') change = item.lastWeekChange;
      else if (period === 'lastMonth') change = item.lastMonthChange;
      else if (period === 'lastYear') change = item.lastYearChange;

      return this.getCellColor(change);
    },

    getTrendIcon(percentChange) {
      if (percentChange === null) return '';

      const change = parseFloat(percentChange);
      if (Math.abs(change) < 2) return '▶';  // Neutral
      return change > 0 ? '▲' : '▼';          // Up or Down
    },

    formatNumber(value, decimals = 0) {
      if (value === null || value === undefined) return '-';
      return Number(value).toFixed(decimals);
    },

    limitProductSelection(value) {
      // Enforce maximum 15 products selection
      if (value && value.length > 15) {
        this.$nextTick(() => {
          this.selectedProductIds = value.slice(0, 15);
        });
      }
    },

    resetFilter() {
      // Re-fetch available years and cascade through filters
      this.fetchAvailableYears();
      // Reset to specific 15 products matching Google Sheets
      if (this.allProducts.length > 0) {
        const targetProductIds = [22, 64, 3, 29, 17, 63, 69, 67, 195, 13, 15, 78, 44, 32, 197];
        this.selectedProductsObjects = this.allProducts.filter(p => targetProductIds.includes(p.id));

        // Fallback to first 15 if specific products not found
        if (this.selectedProductsObjects.length === 0) {
          this.selectedProductsObjects = this.allProducts.slice(0, 15);
        }
      }
    }
  }
};
</script>

<style scoped>
.v-data-table td {
  padding: 8px 4px !important;
}

.v-data-table th {
  font-weight: bold !important;
}

ol {
  padding-left: 20px;
  margin: 0;
}

ol li {
  padding: 4px 0;
  font-size: 14px;
  line-height: 1.5;
}

/* WFP Report Layout Styles */
.report-metadata {
  background-color: #ca5216;
  color: #ffffff;
  padding: 12px;
  font-family: Arial, sans-serif;
}

.country-name {
  font-size: 12pt;
  font-weight: bold;
  margin-bottom: 4px;
}

.issue-number {
  font-size: 10pt;
  margin-bottom: 4px;
}

.week-period {
  font-size: 10pt;
  margin-bottom: 4px;
}

.week-year {
  font-size: 10pt;
}

.report-title {
  background-color: #316caf;
  color: #ffffff;
  font-size: 32pt;
  font-weight: bold;
  text-align: center;
  padding: 20px;
  font-family: Arial, sans-serif;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100px;
}

.wfp-banner {
  width: 100%;
  max-width: 100%;
  height: auto;
  display: block;
}

/* Header icon styling for National Summary table */
.header-with-icon {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.header-icon {
  width: 90px;
  height: 90px;
  object-fit: contain;
  display: block;
}

/* Print Styles for A4 Paper */
@media print {
  /* Page Setup */
  @page {
    size: A4;
    margin: 15mm 10mm;
  }

  /* Hide non-printable elements */
  .v-expansion-panels,
  .v-progress-linear,
  .v-snackbar,
  .no-print {
    display: none !important;
  }

  /* Hide selected products display card */
  .v-card:has(.v-card-title:contains('select_products')) {
    display: none !important;
  }

  /* Force print colors and backgrounds */
  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  /* Remove shadows and elevations for clean print */
  .elevation-1,
  .v-card {
    box-shadow: none !important;
  }

  /* Body and container adjustments */
  body {
    background: white !important;
  }

  .v-application,
  .v-main,
  .container {
    background: white !important;
  }

  /* Full width for print */
  .v-row,
  .v-col {
    max-width: 100% !important;
    flex: 0 0 100% !important;
  }

  /* Report header styling */
  .report-metadata {
    background-color: #ca5216 !important;
    color: #ffffff !important;
    page-break-inside: avoid;
  }

  .report-title {
    background-color: #316caf !important;
    color: #ffffff !important;
    page-break-inside: avoid;
  }

  /* WFP Banner */
  .wfp-banner {
    max-width: 200px;
    page-break-inside: avoid;
  }

  /* Table styling for print */
  .v-data-table {
    border: 1px solid #ddd !important;
  }

  .v-data-table th {
    background-color: #f5f5f5 !important;
    color: #000 !important;
    font-weight: bold !important;
    border: 1px solid #ddd !important;
    padding: 8px 4px !important;
  }

  .v-data-table td {
    border: 1px solid #ddd !important;
    padding: 8px 4px !important;
    color: #000 !important;
  }

  /* Preserve cell background colors */
  .v-data-table td > div[style*="backgroundColor"] {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  /* Card titles */
  .v-card-title {
    color: #009688 !important;
    font-weight: bold !important;
    page-break-after: avoid;
  }

  .v-card-subtitle {
    page-break-after: avoid;
  }

  /* Header icons should print */
  .header-icon {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }

  /* Page break control */
  .v-card {
    page-break-inside: avoid;
    margin-bottom: 10mm;
  }

  /* Product tables - avoid breaking */
  .v-data-table {
    page-break-inside: auto;
  }

  .v-data-table thead {
    display: table-header-group;
  }

  .v-data-table tbody tr {
    page-break-inside: avoid;
    page-break-after: auto;
  }

  /* Each product section */
  .mb-6 {
    page-break-inside: avoid;
    page-break-after: auto;
  }

  /* Remove unnecessary spacing */
  .mb-2,
  .mb-4 {
    margin-bottom: 5mm !important;
  }

  /* Ensure text is readable */
  body,
  .v-application {
    font-size: 10pt;
    line-height: 1.4;
    color: #000 !important;
  }

  /* Remove Vuetify layout padding */
  .v-application--wrap {
    padding: 0 !important;
  }

  .container {
    padding: 0 !important;
    max-width: 100% !important;
  }

  /* Optimize list display */
  ol {
    page-break-inside: avoid;
  }

  ol li {
    font-size: 10pt;
  }
}
</style>
